﻿using UnityEngine;
using System.Collections;

public class WMG_Pie_Graph_Slice : WMG_Node {
	public GameObject objectToMask;
	public float slicePercent;
	public float slicePercentPosition;
	public WMG_Pie_Graph pieRef;
	public int sliceIndex;
}
