﻿using UnityEngine;
using System.Collections;

public class WMG_Legend_Entry : WMG_GUI_Functions {

	public WMG_Legend legend;
	public GameObject label;
	public GameObject swatchNode;
	public GameObject line;
	public GameObject nodeLeft;
	public GameObject nodeRight;
	public WMG_Series seriesRef;
}
